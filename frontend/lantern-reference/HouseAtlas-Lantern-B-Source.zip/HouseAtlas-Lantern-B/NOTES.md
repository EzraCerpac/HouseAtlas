# HouseAtlas Lantern: working notes

Continuation notes for this session. Update as work progresses.

## Concept
"Lantern": the house is presented as a physical architectural model (basswood
slabs with ply laminations, white-card walls cut at sill height, frosted glass
windows) standing on an engraved birch base plate. The selected room glows as a
volume of warm light. Overlays (belongings, electrical, water, network, upkeep)
are colour-coded acrylic pins.

## Tokens
- Ground `#E9E4DA` limestone, panels `#FCFBF8` card, hairline `#D8D0C2`
- Ink `#1E2638`, muted ink `#596173`
- Birch `#D8BE8E` (base plate, slab edges)
- Layers: belongings plum `#9C3F8F`, electrical cobalt `#2F56E0`,
  water viridian `#0B8F83`, network amber `#C08000`, upkeep vermilion `#D93D2E`
- Lantern light `#FFE7A3`
- Type: Bricolage Grotesque Variable (display), Public Sans Variable (UI)

## Architecture (Vite + React + TS, no 3D lib)
- `src/data/types.ts` model, `src/data/alder.ts` (geometry house),
  `src/data/quarry.ts` (no-geometry house), `src/data/query.ts` selectors/search
- `src/state/store.tsx` reducer + simulated write runner
- `src/atlas/geometry.ts` wall/slab derivation, `projection.ts` camera math,
  `Stage.tsx` SVG renderer with topological depth sort, `useCamera.ts` tweening
- `src/components/*` shell, panels, dialogs; `src/views/*` secondary views
- `src/assistant/engine.ts` scripted local "Ask" answers + proposal

## Status
- [x] Config, notes
- [x] types + data (alder.ts, quarry.ts, time.ts, query.ts)
- [x] store (simulated write runner, conflicts, reconcile)
- [x] geometry.ts, projection.ts (+depthSort), palette.ts, glyphs.ts, pins.ts,
      useCamera.ts (generic `useEased`)
- [x] atlas/Model.tsx (SVG renderer: plate, slabs, rooms, walls, furniture, pins,
      lantern, plan marks, callouts, floor tags). Exports computeViewBox, focusIndex,
      plannedFloors, floorZ, plateOf, ModelCam.
- [x] components/Icon.tsx, components/ui.tsx (ClaimBadge, EntityLink, KindTag,
      WritePill, StorageTag, Section, Empty, Note)
- [x] atlas/AtlasView.tsx (camera state, drag/wheel, rail, controls, legend, no-plan panel)
      imports `RoomIndex` from views/RoomsView (still to write)
- [x] components/Art.tsx (ItemArt, MediaScene, MEDIA_TRAY), rows.tsx, DetailPanel.tsx
- [x] components/Modal.tsx, Dialogs.tsx (DialogHost: edit, link, media, complete+next,
      schedule, conflict), Previews.tsx (PreviewDialog with sheets + provenance)
- [x] views: RoomsView (export RoomIndex), UpkeepView, NetworkView, LibraryView, ChangesView
- [x] assistant/engine.ts + components/AskPanel.tsx
- [x] SearchPalette, SettingsDialog, App.tsx (topbar, nav, toasts, sheet), main.tsx
- [x] styles: tokens.css, app.css (shell/forms/modal/palette/toasts/responsive),
      atlas.css (stage/model/controls/legend), panels.css (detail/views/ask/previews)
- [x] Self-review pass 1 (ModelCam as type alias, makeWrite origin, runner key)
- [x] Self-review pass 2 (Task literal widening in store map, computed-key spreads,
      non-scaling dash arrays, phone top bar widths, modal z-order above Ask)
- [x] README.md with run instructions and dependency list
- [ ] Remaining: supervisor build + browser QA (no shell in this session, so the
      code has not been compiled here). Possible follow-ups: tune camera
      defaults after seeing it render; check SVG text sizes in plan view.
- [ ] shell + detail panel
- [ ] dialogs (edit, link, media, complete, schedule, preview, conflict)
- [ ] views (rooms, upkeep, network, library, changes)
- [ ] assistant
- [ ] CSS polish + responsive
