import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative base so the built preview can be opened from any folder.
export default defineConfig({
  base: './',
  plugins: [react()],
});
