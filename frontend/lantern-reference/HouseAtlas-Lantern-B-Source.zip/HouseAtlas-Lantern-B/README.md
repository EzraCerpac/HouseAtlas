# HouseAtlas Lantern (concept mock)

An interactive concept for HouseAtlas, a private household memory. The house is
shown as a physical architectural model that you can turn, tilt, explode and
flatten into a plan. The selected room lights up.

All houses, people, records, documents and plans are fictional demo data.
Everything runs in the browser from memory. There are no network requests,
accounts or AI services, and every "save" is simulated.

## Run

```sh
npm install
npm run dev        # local dev server
npm run build      # type-check and build to dist/
npm run preview    # serve the built files
```

The build uses a relative base path, so `dist/` can be opened from any folder
by a static server.

## Dependencies

- react, react-dom
- @fontsource-variable/bricolage-grotesque, @fontsource-variable/public-sans
  (fonts are bundled, nothing is fetched at runtime)
- Dev: vite, @vitejs/plugin-react, typescript, @types/react, @types/react-dom

The 3D model is hand-built SVG (orthographic projection, depth-sorted boxes).
No 3D library is used.

## Source map

- `src/data` fictional houses, types, selectors, search, fixed demo clock
- `src/state/store.tsx` app state and the simulated write runner
- `src/atlas` geometry, projection, depth sort, model renderer, stage controls
- `src/components` detail panel, dialogs, previews, search, settings, assistant
- `src/views` rooms, upkeep, network, library, changes
- `src/assistant/engine.ts` scripted, local "Ask" answers and the proposal
