import { useStore } from '../state/store';
import { Modal } from './Modal';
import { fmtDate } from '../data/time';

export function SettingsDialog() {
  const { state, dispatch } = useStore();
  const s = state.settings;
  const close = () => dispatch({ type: 'settingsOpen', open: false });
  const set = (patch: Partial<typeof s>) => dispatch({ type: 'settings', patch });
  return (
    <Modal
      title="Settings"
      kicker="Demo preferences, kept in this tab only"
      onClose={close}
      footer={
        <button type="button" className="btn btn-primary" onClick={close}>
          Done
        </button>
      }
    >
      <div className="settings">
        <fieldset className="field radio-cards">
          <legend>House</legend>
          {Object.values(state.houses).map((h) => (
            <label key={h.id} className={`radio-card${state.houseId === h.id ? ' is-on' : ''}`}>
              <input
                type="radio"
                name="house"
                checked={state.houseId === h.id}
                onChange={() => {
                  dispatch({ type: 'house', id: h.id });
                  dispatch({ type: 'toast', text: `Switched to ${h.name}.`, tone: 'info' });
                }}
              />
              <span className="radio-title">{h.name}</span>
              <span className="radio-help">
                {h.tagline}. {h.geometry === 'reviewed' && h.sources.geometryReviewedAt ? `Plan reviewed ${fmtDate(h.sources.geometryReviewedAt)}.` : 'Browse by room.'} Fictional.
              </span>
            </label>
          ))}
        </fieldset>

        <div className="field">
          <span className="field-label">Language</span>
          <p className="setting-static">English. This demo has no other languages.</p>
        </div>

        <fieldset className="field radio-cards">
          <legend>Assistant</legend>
          <label className={`radio-card${s.assistant === 'demo' ? ' is-on' : ''}`}>
            <input type="radio" name="assistant" checked={s.assistant === 'demo'} onChange={() => set({ assistant: 'demo' })} />
            <span className="radio-title">Demo, scripted</span>
            <span className="radio-help">Answers are worked out from the fictional records in your browser. No AI service is connected, and nothing is sent anywhere.</span>
          </label>
          <label className={`radio-card${s.assistant === 'off' ? ' is-on' : ''}`}>
            <input type="radio" name="assistant" checked={s.assistant === 'off'} onChange={() => set({ assistant: 'off' })} />
            <span className="radio-title">Off</span>
            <span className="radio-help">Hide answers and proposals. Search and records work as normal.</span>
          </label>
        </fieldset>

        <fieldset className="field">
          <legend>Simulate problems</legend>
          <label className="switch">
            <input type="checkbox" checked={s.outage} onChange={(e) => set({ outage: e.target.checked })} />
            <span className="switch-track" aria-hidden="true" />
            <span>
              <span className="radio-title">HomeBox unreachable</span>
              <span className="radio-help">Browse the cached copy with its age shown. HomeBox edits pause; nothing is queued offline.</span>
            </span>
          </label>
          <label className="switch">
            <input type="checkbox" checked={s.slowWrites} onChange={(e) => set({ slowWrites: e.target.checked })} />
            <span className="switch-track" aria-hidden="true" />
            <span>
              <span className="radio-title">Slow HomeBox answers</span>
              <span className="radio-help">New HomeBox saves end as “Result unknown” so you can practise checking them.</span>
            </span>
          </label>
        </fieldset>

        <fieldset className="field">
          <legend>Motion</legend>
          <div className="seg" role="radiogroup" aria-label="Motion">
            {(
              [
                ['system', 'Follow system'],
                ['reduce', 'Reduce'],
                ['full', 'Full'],
              ] as const
            ).map(([v, l]) => (
              <button key={v} type="button" role="radio" aria-checked={s.motion === v} onClick={() => set({ motion: v })}>
                {l}
              </button>
            ))}
          </div>
        </fieldset>
      </div>
    </Modal>
  );
}
