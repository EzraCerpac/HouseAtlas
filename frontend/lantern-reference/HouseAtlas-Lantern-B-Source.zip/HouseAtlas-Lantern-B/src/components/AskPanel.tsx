import { useEffect, useRef, useState, type FormEvent } from 'react';
import { answer, suggestions, type AnswerEntry, type AskEntry, type Citation, type ProposalEntry, type Seg } from '../assistant/engine';
import { kindOf, nameOf } from '../data/query';
import { fmtDate } from '../data/time';
import { makeWrite, useSelect, useStore } from '../state/store';
import { Icon } from './Icon';
import { ClaimBadge, KindTag, WritePill } from './ui';

export function AskPanel() {
  const { state, dispatch, house } = useStore();
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const [thinking, setThinking] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const entries = state.ask[house.id] ?? [];
  const off = state.settings.assistant === 'off';

  useEffect(() => {
    inputRef.current?.focus();
  }, []);
  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: 'smooth' });
  }, [entries.length, thinking]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !state.dialog) dispatch({ type: 'ask', open: false });
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [dispatch, state.dialog]);

  const ask = (q: string) => {
    const question = q.trim();
    if (!question) {
      setError('Type a question first, or pick one of the suggestions.');
      return;
    }
    if (question.length > 200) {
      setError('Keep the question under 200 characters.');
      return;
    }
    setError('');
    setText('');
    setThinking(true);
    window.setTimeout(() => {
      dispatch({ type: 'askPush', entry: answer(house, question) });
      setThinking(false);
    }, 420);
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    ask(text);
  };

  return (
    <aside className="ask" aria-labelledby="ask-title">
      <header className="ask-head">
        <div>
          <h2 id="ask-title">Ask the atlas</h2>
          <p className="ask-status">
            <span className={`ask-dot${off ? ' is-off' : ''}`} aria-hidden="true" />
            {off ? 'Assistant is off.' : 'Demo assistant. Scripted answers from this fictional house, worked out in your browser. No AI service is connected.'}
          </p>
        </div>
        <button type="button" className="icon-btn" aria-label="Close assistant" onClick={() => dispatch({ type: 'ask', open: false })}>
          <Icon name="close" size={18} />
        </button>
      </header>

      {off ? (
        <div className="ask-off">
          <p>The assistant is switched off in settings. Search and every record still work without it.</p>
          <button type="button" className="btn" onClick={() => dispatch({ type: 'settingsOpen', open: true })}>
            Open settings
          </button>
        </div>
      ) : (
        <>
          <div className="ask-log" ref={logRef} aria-live="polite">
            {entries.length === 0 && (
              <div className="ask-empty">
                <p>Ask about where things are, what is due, how something is powered or what the network last reported. Answers link to the records they come from.</p>
                <p>Ask it to tidy a record and it will show a proposal for you to review first.</p>
              </div>
            )}
            {entries.map((e) => (e.kind === 'answer' ? <Answer key={e.id} entry={e} /> : <Proposal key={e.id} entry={e} />))}
            {thinking && (
              <p className="ask-thinking" role="status">
                Reading the records
              </p>
            )}
          </div>
          <div className="ask-suggest" role="group" aria-label="Suggested questions">
            {suggestions(house).map((s) => (
              <button key={s} type="button" className="chip-btn" onClick={() => ask(s)} disabled={thinking}>
                {s}
              </button>
            ))}
          </div>
          <form className="ask-form" onSubmit={submit} noValidate>
            <label htmlFor="ask-input" className="sr-only">
              Your question
            </label>
            <input
              id="ask-input"
              ref={inputRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Where is the camping tent?"
              aria-invalid={!!error}
              aria-describedby={error ? 'ask-error' : undefined}
              autoComplete="off"
            />
            <button type="submit" className="btn btn-primary" disabled={thinking}>
              Ask
            </button>
            {error && (
              <p id="ask-error" className="field-error" role="alert">
                {error}
              </p>
            )}
          </form>
          {entries.length > 0 && (
            <button type="button" className="text-btn ask-clear" onClick={() => dispatch({ type: 'askClear' })}>
              Clear this conversation
            </button>
          )}
        </>
      )}
    </aside>
  );
}

function Rich({ segs, citations }: { segs: Seg[]; citations: Citation[] }) {
  const { house } = useStore();
  const select = useSelect();
  return (
    <>
      {segs.map((s, i) => {
        if (typeof s === 'string') return <span key={i}>{s}</span>;
        if ('ref' in s) {
          const exists = !!kindOf(s.ref);
          return exists ? (
            <button key={i} type="button" className="inline-ref" onClick={() => select(s.ref)}>
              {nameOf(house, s.ref)}
            </button>
          ) : (
            <span key={i}>{s.ref}</span>
          );
        }
        const c = citations.find((x) => x.n === s.cite);
        return (
          <button key={i} type="button" className="cite" aria-label={`Source ${s.cite}${c ? `: ${nameOf(house, c.id)}` : ''}`} onClick={() => c && select(c.id)}>
            {s.cite}
          </button>
        );
      })}
    </>
  );
}

function Sources({ citations }: { citations: Citation[] }) {
  const { house } = useStore();
  const select = useSelect();
  if (!citations.length) return null;
  return (
    <ol className="ask-sources" aria-label="Sources">
      {citations.map((c) => {
        const k = kindOf(c.id);
        return (
          <li key={c.n}>
            <span className="cite cite-static" aria-hidden="true">
              {c.n}
            </span>
            <button type="button" className="source-link" onClick={() => select(c.id)}>
              {k && <KindTag kind={k} />}
              <span className="source-name">{nameOf(house, c.id)}</span>
              <span className="source-why">
                {c.why}
                {c.when ? `, ${fmtDate(c.when)}` : ''}
              </span>
            </button>
            {c.claim && <ClaimBadge claim={c.claim} />}
          </li>
        );
      })}
    </ol>
  );
}

function Answer({ entry }: { entry: AnswerEntry }) {
  return (
    <article className="ask-entry">
      <p className="ask-q">{entry.question}</p>
      <div className="ask-a">
        {entry.paras.map((p, i) => (
          <p key={i}>
            <Rich segs={p} citations={entry.citations} />
          </p>
        ))}
        {entry.caveat && <p className="ask-caveat">{entry.caveat}</p>}
        <Sources citations={entry.citations} />
      </div>
    </article>
  );
}

function Proposal({ entry }: { entry: ProposalEntry }) {
  const { dispatch, house, state } = useStore();
  const update = (next: AskEntry) => dispatch({ type: 'askUpdate', id: entry.id, entry: next });
  const selected = entry.changes.filter((c) => c.selected);
  const homeboxBlocked = state.settings.outage && selected.some((c) => c.system === 'HomeBox');

  const apply = () => {
    const changes = entry.changes.map((c) => {
      if (!c.selected) return c;
      const w = makeWrite({ title: c.title, targetId: c.targetId, system: c.system, patch: c.patch, origin: 'assistant', forceOutcome: c.forceOutcome, conflict: c.conflict });
      dispatch({ type: 'queueWrite', write: w });
      return { ...c, writeId: w.id };
    });
    update({ ...entry, changes, state: 'applied' });
    dispatch({ type: 'toast', text: `Applying ${selected.length} ${selected.length === 1 ? 'change' : 'changes'} (simulated).`, tone: 'info' });
  };

  return (
    <article className="ask-entry ask-proposal">
      <p className="ask-q">{entry.question}</p>
      <div className="ask-a">
        <p>
          <Rich segs={entry.intro} citations={entry.citations} />
        </p>
        <ul className="proposal-list">
          {entry.changes.map((c) => {
            const w = c.writeId ? house.writes.find((x) => x.id === c.writeId) : undefined;
            return (
              <li key={c.key} className={`proposal-item${c.selected ? ' is-on' : ''}`}>
                {entry.state === 'review' ? (
                  <label className="proposal-check">
                    <input
                      type="checkbox"
                      checked={c.selected}
                      onChange={(e) => update({ ...entry, changes: entry.changes.map((x) => (x.key === c.key ? { ...x, selected: e.target.checked } : x)) })}
                    />
                    <span className="proposal-title">{c.title}</span>
                  </label>
                ) : (
                  <span className="proposal-title">{c.title}</span>
                )}
                <span className="proposal-detail">{c.detail}</span>
                <span className="proposal-meta">
                  <span className="write-system">{c.system}</span>
                  {entry.state === 'applied' && (w ? <WritePill status={w.status} /> : <span className="write-pill write-discarded">Skipped</span>)}
                  {w?.status === 'conflict' && (
                    <button type="button" className="btn btn-small" onClick={() => dispatch({ type: 'dialog', dialog: { type: 'conflict', writeId: w.id } })}>
                      Review conflict
                    </button>
                  )}
                  {w?.note && w.status !== 'completed' && <span className="proposal-note">{w.note}</span>}
                </span>
              </li>
            );
          })}
        </ul>
        {entry.state === 'review' && (
          <div className="proposal-actions">
            <button type="button" className="btn btn-primary" disabled={!selected.length || homeboxBlocked} title={homeboxBlocked ? 'HomeBox is unreachable. Untick the HomeBox changes or wait until it reconnects.' : undefined} onClick={apply}>
              Apply {selected.length} {selected.length === 1 ? 'change' : 'changes'}
            </button>
            <button type="button" className="btn" onClick={() => update({ ...entry, state: 'dismissed' })}>
              Dismiss
            </button>
            <span className="fine">Simulated. Nothing leaves this browser.</span>
          </div>
        )}
        {entry.state === 'dismissed' && <p className="ask-caveat">Dismissed. Nothing was changed.</p>}
        {entry.state === 'applied' && (
          <p className="ask-caveat">
            Each change is saved on its own. Follow them in{' '}
            <button type="button" className="text-btn inline" onClick={() => dispatch({ type: 'view', view: 'changes' })}>
              Changes
            </button>
            .
          </p>
        )}
        <Sources citations={entry.citations} />
      </div>
    </article>
  );
}
