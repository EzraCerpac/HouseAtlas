// The demo runs on a fixed clock so relative times read the same for everyone.
export const DEMO_NOW = new Date('2026-10-07T10:00:00');
export const DEMO_TODAY = '2026-10-07';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function parse(iso: string): Date {
  // Date-only strings are treated as local midnight, not UTC.
  return iso.length === 10 ? new Date(`${iso}T00:00:00`) : new Date(iso);
}

export function fmtDate(iso?: string): string {
  if (!iso) return 'No date';
  const d = parse(iso);
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function fmtShortDate(iso?: string): string {
  if (!iso) return 'No date';
  const d = parse(iso);
  const sameYear = d.getFullYear() === DEMO_NOW.getFullYear();
  return sameYear ? `${d.getDate()} ${MONTHS[d.getMonth()]}` : `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function fmtTime(iso: string): string {
  const d = parse(iso);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function fmtDateTime(iso?: string): string {
  if (!iso) return 'Unknown time';
  return `${fmtDate(iso)}, ${fmtTime(iso)}`;
}

/** "3 h ago", "yesterday", "in 4 days". */
export function rel(iso?: string): string {
  if (!iso) return 'unknown';
  const d = parse(iso);
  const diff = DEMO_NOW.getTime() - d.getTime();
  const abs = Math.abs(diff);
  const min = 60_000;
  const hr = 60 * min;
  const day = 24 * hr;
  const future = diff < 0;
  if (abs < min) return 'just now';
  if (abs < hr) {
    const m = Math.round(abs / min);
    return future ? `in ${m} min` : `${m} min ago`;
  }
  if (abs < day && iso.length > 10) {
    const h = Math.round(abs / hr);
    return future ? `in ${h} h` : `${h} h ago`;
  }
  const days = daysBetween(DEMO_TODAY, iso.slice(0, 10));
  if (days === 0) return 'today';
  if (days === 1) return 'tomorrow';
  if (days === -1) return 'yesterday';
  if (days > 0) return days < 45 ? `in ${days} days` : `in ${Math.round(days / 30)} months`;
  const past = -days;
  if (past < 45) return `${past} days ago`;
  if (past < 540) return `${Math.round(past / 30)} months ago`;
  return `${Math.round(past / 365)} years ago`;
}

export function daysBetween(fromDate: string, toDate: string): number {
  const a = parse(fromDate.slice(0, 10)).getTime();
  const b = parse(toDate.slice(0, 10)).getTime();
  return Math.round((b - a) / 86_400_000);
}

export function daysUntil(date?: string): number | undefined {
  if (!date) return undefined;
  return daysBetween(DEMO_TODAY, date);
}

export function addDays(date: string, n: number): string {
  const d = parse(date.slice(0, 10));
  d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Simulated clock for new writes: the demo "now" plus real elapsed seconds. */
const started = Date.now();
export function demoNowIso(): string {
  const d = new Date(DEMO_NOW.getTime() + (Date.now() - started));
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
