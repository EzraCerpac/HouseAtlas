import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useSyncExternalStore,
  type Dispatch,
  type ReactNode,
} from 'react';
import { alderRow } from '../data/alder';
import { quarryLane } from '../data/quarry';
import { OVERLAY_FOR_KIND, kindOf as kindFromId, locate } from '../data/query';
import { demoNowIso } from '../data/time';
import type {
  ConflictInfo,
  HouseData,
  HistoryEvent,
  Overlay,
  Patch,
  Selection,
  System,
  Task,
  WriteOp,
  WriteStatus,
} from '../data/types';
import type { AskEntry } from '../assistant/engine';

export type ViewId = 'atlas' | 'rooms' | 'upkeep' | 'network' | 'library' | 'changes';

export type Dialog =
  | { type: 'editItem'; itemId: string }
  | { type: 'link'; targetId: string }
  | { type: 'media'; targetId: string }
  | { type: 'complete'; taskId: string }
  | { type: 'schedule'; targetId: string; afterTaskId?: string }
  | { type: 'preview'; docId: string }
  | { type: 'conflict'; writeId: string };

export interface Settings {
  outage: boolean;
  slowWrites: boolean;
  motion: 'system' | 'reduce' | 'full';
  assistant: 'demo' | 'off';
}

export interface Toast {
  id: number;
  text: string;
  tone: 'ok' | 'info' | 'warn';
}

export interface AppState {
  houseId: string;
  houses: Record<string, HouseData>;
  view: ViewId;
  selection: Selection | null;
  floorId: string;
  mode: '3d' | '2d';
  exploded: boolean;
  overlay: Overlay;
  focusCircuit?: string;
  dialog: Dialog | null;
  searchOpen: boolean;
  askOpen: boolean;
  settingsOpen: boolean;
  toasts: Toast[];
  settings: Settings;
  ask: Record<string, AskEntry[]>;
  changesFocus?: string;
}

export type Action =
  | { type: 'house'; id: string }
  | { type: 'view'; view: ViewId; focus?: string }
  | { type: 'select'; sel: Selection | null; keepOverlay?: boolean; view?: ViewId }
  | { type: 'floor'; id: string }
  | { type: 'mode'; mode: '3d' | '2d' }
  | { type: 'explode'; on: boolean }
  | { type: 'overlay'; overlay: Overlay }
  | { type: 'focusCircuit'; id?: string }
  | { type: 'dialog'; dialog: Dialog | null }
  | { type: 'search'; open: boolean }
  | { type: 'ask'; open: boolean }
  | { type: 'settingsOpen'; open: boolean }
  | { type: 'settings'; patch: Partial<Settings> }
  | { type: 'toast'; text: string; tone?: Toast['tone'] }
  | { type: 'dismissToast'; id: number }
  | { type: 'queueWrite'; write: WriteOp }
  | { type: 'writeStatus'; houseId: string; id: string; status: WriteStatus; note?: string }
  | { type: 'resolveConflict'; id: string; choice: 'theirs' | 'mine' | 'custom'; value?: string }
  | { type: 'reconcile'; id: string; how: 'check' | 'retry' }
  | { type: 'discardWrite'; id: string }
  | { type: 'askPush'; entry: AskEntry }
  | { type: 'askUpdate'; id: string; entry: AskEntry }
  | { type: 'askClear' };

const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x)) as T;

let toastSeq = 1;
let writeSeq = 1;
let histSeq = 1;

const initial: AppState = {
  houseId: 'alder',
  houses: { alder: clone(alderRow), quarry: clone(quarryLane) },
  view: 'atlas',
  selection: null,
  floorId: 'fl-g',
  mode: '3d',
  exploded: true,
  overlay: 'spaces',
  dialog: null,
  searchOpen: false,
  askOpen: false,
  settingsOpen: false,
  toasts: [],
  settings: { outage: false, slowWrites: false, motion: 'system', assistant: 'demo' },
  ask: {},
};

function defaultFloor(h: HouseData): string {
  const planned = h.floors.filter((f) => f.hasPlan).sort((a, b) => a.order - b.order);
  // Prefer the entrance level (second planned floor) when there are several.
  if (planned.length >= 2) return planned[1].id;
  if (planned.length) return planned[0].id;
  return [...h.floors].sort((a, b) => a.order - b.order)[0]?.id ?? '';
}

function hist(targetId: string, what: string, system: HistoryEvent['system'], who = 'You'): HistoryEvent {
  return { id: `h-local-${histSeq++}`, targetId, at: demoNowIso(), who, what, system };
}

function applyPatch(h: HouseData, w: WriteOp): HouseData {
  const p = w.patch;
  const next = { ...h };
  const events: HistoryEvent[] = [];
  switch (p.op) {
    case 'updateItem':
      next.items = h.items.map((it) => (it.id === p.id ? { ...it, ...p.set, rev: it.rev + 1 } : it));
      events.push(hist(p.id, w.title, w.system));
      break;
    case 'renameContainer':
      next.containers = h.containers.map((c) => (c.id === p.id ? { ...c, name: p.name, rev: c.rev + 1 } : c));
      events.push(hist(p.id, w.title, w.system));
      break;
    case 'linkDoc':
      next.docs = h.docs.map((d) => (d.id === p.docId && !d.linkedTo.includes(p.targetId) ? { ...d, linkedTo: [...d.linkedTo, p.targetId] } : d));
      if (p.targetId.startsWith('mt-')) {
        next.tasks = h.tasks.map((t) => (t.id === p.targetId ? { ...t, docIds: [...(t.docIds ?? []), p.docId] } : t));
      }
      events.push(hist(p.targetId, w.title, w.system));
      break;
    case 'addDoc':
      next.docs = [...h.docs, p.doc];
      for (const t of p.doc.linkedTo) events.push(hist(t, w.title, w.system));
      break;
    case 'completeTask':
      next.tasks = h.tasks.map((t): Task =>
        t.id === p.id
          ? { ...t, status: 'done', completedAt: p.completedAt, completedBy: p.completedBy, note: p.note, evidenceIds: p.evidenceIds }
          : t,
      );
      {
        const t = h.tasks.find((x) => x.id === p.id);
        if (t) events.push(hist(t.targetId, w.title, w.system, p.completedBy));
        events.push(hist(p.id, w.title, w.system, p.completedBy));
      }
      break;
    case 'addTask':
      next.tasks = [...h.tasks, p.task];
      events.push(hist(p.task.targetId, w.title, w.system));
      break;
    case 'none':
      break;
  }
  next.history = [...h.history, ...events];
  return next;
}

function patchHouse(s: AppState, houseId: string, fn: (h: HouseData) => HouseData): AppState {
  return { ...s, houses: { ...s.houses, [houseId]: fn(s.houses[houseId]) } };
}

function setWrite(h: HouseData, id: string, patch: Partial<WriteOp>): HouseData {
  return { ...h, writes: h.writes.map((w) => (w.id === id ? { ...w, ...patch, updatedAt: demoNowIso() } : w)) };
}

function reducer(s: AppState, a: Action): AppState {
  switch (a.type) {
    case 'house': {
      const h = s.houses[a.id];
      return { ...s, houseId: a.id, selection: null, floorId: defaultFloor(h), overlay: 'spaces', focusCircuit: undefined, mode: '3d' };
    }
    case 'view':
      return { ...s, view: a.view, changesFocus: a.focus ?? s.changesFocus };
    case 'select': {
      if (!a.sel) return { ...s, selection: null, focusCircuit: undefined };
      const h = s.houses[s.houseId];
      const loc = locate(h, a.sel.id);
      const overlay = a.keepOverlay ? s.overlay : (OVERLAY_FOR_KIND[a.sel.kind] ?? s.overlay);
      let focusCircuit: string | undefined;
      if (a.sel.kind === 'circuit') focusCircuit = a.sel.id;
      if (a.sel.kind === 'outlet') focusCircuit = h.outlets.find((o) => o.id === a.sel!.id)?.circuitId;
      return {
        ...s,
        selection: a.sel,
        floorId: loc.floorId ?? s.floorId,
        overlay,
        focusCircuit,
        view: a.view ?? s.view,
      };
    }
    case 'floor':
      return { ...s, floorId: a.id };
    case 'mode':
      return { ...s, mode: a.mode };
    case 'explode':
      return { ...s, exploded: a.on };
    case 'overlay':
      return { ...s, overlay: a.overlay, focusCircuit: a.overlay === 'electrical' ? s.focusCircuit : undefined };
    case 'focusCircuit':
      return { ...s, focusCircuit: a.id };
    case 'dialog':
      return { ...s, dialog: a.dialog };
    case 'search':
      return { ...s, searchOpen: a.open };
    case 'ask':
      return { ...s, askOpen: a.open };
    case 'settingsOpen':
      return { ...s, settingsOpen: a.open };
    case 'settings':
      return { ...s, settings: { ...s.settings, ...a.patch } };
    case 'toast':
      return { ...s, toasts: [...s.toasts.slice(-3), { id: toastSeq++, text: a.text, tone: a.tone ?? 'ok' }] };
    case 'dismissToast':
      return { ...s, toasts: s.toasts.filter((t) => t.id !== a.id) };
    case 'queueWrite':
      return patchHouse(s, s.houseId, (h) => ({ ...h, writes: [...h.writes, a.write] }));
    case 'writeStatus':
      return patchHouse(s, a.houseId, (h) => {
        const w = h.writes.find((x) => x.id === a.id);
        if (!w || w.status === 'discarded') return h;
        let next = setWrite(h, a.id, { status: a.status, note: a.note ?? w.note });
        if (a.status === 'completed') next = applyPatch(next, w);
        if (a.status === 'conflict' && w.conflict) next = refreshFromUpstream(next, w);
        return next;
      });
    case 'resolveConflict':
      return patchHouse(s, s.houseId, (h) => {
        const w = h.writes.find((x) => x.id === a.id);
        if (!w || !w.conflict) return h;
        if (a.choice === 'theirs') {
          const next = setWrite(h, a.id, { status: 'discarded', note: `Kept the HomeBox version "${w.conflict.theirs}".` });
          return { ...next, history: [...next.history, hist(w.targetId, `Conflict resolved: kept "${w.conflict.theirs}"`, w.system)] };
        }
        const value = a.choice === 'custom' ? (a.value ?? '').trim() : w.conflict.mine;
        const resolvedPatch = withValue(w.patch, value, w.conflict);
        const retry: WriteOp = {
          ...w,
          id: `wr-${writeSeq++}`,
          title: `${w.title} (resolved on revision ${w.conflict.theirsRev})`,
          status: 'queued',
          createdAt: demoNowIso(),
          updatedAt: demoNowIso(),
          patch: resolvedPatch,
          forceOutcome: 'completed',
          conflict: undefined,
          note: undefined,
        };
        const next = setWrite(h, a.id, { status: 'discarded', note: `Replaced by a resolved write based on revision ${w.conflict.theirsRev}.` });
        return { ...next, writes: [...next.writes, retry] };
      });
    case 'reconcile':
      return patchHouse(s, s.houseId, (h) => {
        const w = h.writes.find((x) => x.id === a.id);
        if (!w) return h;
        if (a.how === 'check') {
          // Simulated read-back: HomeBox shows the change did land.
          const next = setWrite(h, a.id, { status: 'completed', note: 'Checked HomeBox: the change is there.' });
          return applyPatch(next, w);
        }
        return setWrite(h, a.id, { status: 'queued', forceOutcome: 'completed', note: 'Sent again.' });
      });
    case 'discardWrite':
      return patchHouse(s, s.houseId, (h) => setWrite(h, a.id, { status: 'discarded', note: 'Discarded. Nothing was changed.' }));
    case 'askPush':
      return { ...s, ask: { ...s.ask, [s.houseId]: [...(s.ask[s.houseId] ?? []), a.entry] } };
    case 'askUpdate':
      return { ...s, ask: { ...s.ask, [s.houseId]: (s.ask[s.houseId] ?? []).map((e) => (e.id === a.id ? a.entry : e)) } };
    case 'askClear':
      return { ...s, ask: { ...s.ask, [s.houseId]: [] } };
    default:
      return s;
  }
}

/** A conflict means HomeBox has a newer revision: the cached copy picks it up. */
function refreshFromUpstream(h: HouseData, w: WriteOp): HouseData {
  const c = w.conflict!;
  const p = w.patch;
  if (p.op === 'updateItem') {
    const byName = c.field === 'Name';
    return {
      ...h,
      items: h.items.map((it) =>
        it.id !== p.id ? it : byName ? { ...it, name: c.theirs, rev: c.theirsRev } : { ...it, note: c.theirs, rev: c.theirsRev },
      ),
      history: [...h.history, hist(p.id, `${c.field} changed to "${c.theirs}" (revision ${c.theirsRev})`, 'HomeBox', c.theirsBy)],
    };
  }
  if (p.op === 'renameContainer') {
    return { ...h, containers: h.containers.map((x) => (x.id === p.id ? { ...x, name: c.theirs, rev: c.theirsRev } : x)) };
  }
  return h;
}

function withValue(p: Patch, value: string, c: ConflictInfo): Patch {
  if (p.op === 'renameContainer') return { ...p, name: value };
  if (p.op === 'updateItem') {
    return { ...p, set: c.field === 'Name' ? { ...p.set, name: value } : { ...p.set, note: value } };
  }
  return p;
}

export function makeWrite(input: {
  title: string;
  targetId: string;
  system: System;
  patch: Patch;
  origin?: 'you' | 'assistant';
  forceOutcome?: WriteOp['forceOutcome'];
  conflict?: ConflictInfo;
}): WriteOp {
  const now = demoNowIso();
  return {
    ...input,
    id: `wr-${writeSeq++}`,
    status: 'queued',
    createdAt: now,
    updatedAt: now,
    origin: input.origin ?? 'you',
  };
}

interface Ctx {
  state: AppState;
  dispatch: Dispatch<Action>;
  house: HouseData;
}

const StoreContext = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initial);
  const scheduled = useRef(new Set<string>());
  const stateRef = useRef(state);
  stateRef.current = state;

  // Simulated write runner: queued -> running -> outcome. Nothing leaves the browser.
  useEffect(() => {
    for (const [houseId, h] of Object.entries(state.houses)) {
      for (const w of h.writes) {
        // updatedAt is part of the key so a retried write is scheduled again.
        const key = `${houseId}:${w.id}:${w.status}:${w.updatedAt}`;
        if ((w.status !== 'queued' && w.status !== 'running') || scheduled.current.has(key)) continue;
        scheduled.current.add(key);
        if (w.status === 'queued') {
          window.setTimeout(() => dispatch({ type: 'writeStatus', houseId, id: w.id, status: 'running' }), 650);
        } else {
          window.setTimeout(() => {
            const st = stateRef.current;
            const current = st.houses[houseId].writes.find((x) => x.id === w.id);
            if (!current || current.status !== 'running') return;
            let outcome: WriteStatus = current.forceOutcome ?? 'completed';
            let note: string | undefined;
            if (!current.forceOutcome && current.system === 'HomeBox') {
              if (st.settings.outage) {
                outcome = 'uncertain';
                note = 'HomeBox stopped answering while this was being sent.';
              } else if (st.settings.slowWrites) {
                outcome = 'uncertain';
                note = 'HomeBox did not answer in time. The change may or may not have been saved.';
              }
            }
            if (outcome === 'conflict') note = 'HomeBox has a newer revision. Review before anything is overwritten.';
            dispatch({ type: 'writeStatus', houseId, id: w.id, status: outcome, note });
            const tone = outcome === 'completed' ? 'ok' : 'warn';
            const text =
              outcome === 'completed'
                ? `Saved: ${current.title}`
                : outcome === 'conflict'
                  ? `Needs review: ${current.title}`
                  : `Result unknown: ${current.title}`;
            dispatch({ type: 'toast', text, tone });
          }, 1500);
        }
      }
    }
  }, [state.houses]);

  const value = useMemo(() => ({ state, dispatch, house: state.houses[state.houseId] }), [state]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): Ctx {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore outside provider');
  return ctx;
}

export function useSelect() {
  const { dispatch } = useStore();
  return useCallback(
    (id: string | null, opts?: { keepOverlay?: boolean; view?: ViewId }) => {
      if (!id) return dispatch({ type: 'select', sel: null });
      const kind = kindFromId(id);
      if (!kind) return;
      dispatch({ type: 'select', sel: { kind, id }, ...opts });
    },
    [dispatch],
  );
}

function subscribeMotion(cb: () => void) {
  const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
  mq.addEventListener('change', cb);
  return () => mq.removeEventListener('change', cb);
}

export function useReducedMotion(): boolean {
  const { state } = useStore();
  const system = useSyncExternalStore(
    subscribeMotion,
    () => window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    () => false,
  );
  if (state.settings.motion === 'reduce') return true;
  if (state.settings.motion === 'full') return false;
  return system;
}

/** HomeBox-owned edits are blocked during a simulated outage. */
export function useCanWrite(system: System): { ok: boolean; reason?: string } {
  const { state } = useStore();
  if (system === 'HomeBox' && state.settings.outage) {
    return { ok: false, reason: 'HomeBox is unreachable. You can browse the cached copy, but edits to HomeBox records are paused until it reconnects. Nothing is queued offline.' };
  }
  return { ok: true };
}
