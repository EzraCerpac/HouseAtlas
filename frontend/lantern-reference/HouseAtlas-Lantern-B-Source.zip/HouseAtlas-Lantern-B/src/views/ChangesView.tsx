import { useEffect, useRef } from 'react';
import type { WriteOp } from '../data/types';
import { nameOf } from '../data/query';
import { fmtDateTime, fmtTime } from '../data/time';
import { useCanWrite, useStore } from '../state/store';
import { EntityLink, Empty, Note, WritePill } from '../components/ui';
import { Sources } from '../components/DetailPanel';

function WriteRow({ w, focused }: { w: WriteOp; focused: boolean }) {
  const { dispatch, house } = useStore();
  const can = useCanWrite(w.system);
  const ref = useRef<HTMLLIElement>(null);
  useEffect(() => {
    if (focused) ref.current?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }, [focused]);
  return (
    <li ref={ref} className={`write-row write-row-${w.status}${focused ? ' is-focused' : ''}`}>
      <div className="write-top">
        <WritePill status={w.status} />
        <span className="write-system">{w.system}</span>
        {w.origin === 'assistant' && <span className="write-origin">From an assistant proposal</span>}
      </div>
      <p className="write-title">{w.title}</p>
      <p className="write-meta">
        Sent {fmtDateTime(w.createdAt)}
        {w.updatedAt !== w.createdAt ? `, updated ${fmtTime(w.updatedAt)}` : ''}. Record: <EntityLink id={w.targetId} label={nameOf(house, w.targetId)} />
      </p>
      {w.note && <p className="write-note">{w.note}</p>}
      {w.status === 'conflict' && (
        <div className="write-actions">
          <button type="button" className="btn btn-primary btn-small" onClick={() => dispatch({ type: 'dialog', dialog: { type: 'conflict', writeId: w.id } })}>
            Review conflict
          </button>
        </div>
      )}
      {w.status === 'uncertain' && (
        <>
          <div className="write-actions">
            <button
              type="button"
              className="btn btn-primary btn-small"
              disabled={!can.ok}
              title={can.reason}
              onClick={() => {
                dispatch({ type: 'reconcile', id: w.id, how: 'check' });
                dispatch({ type: 'toast', text: `Checked ${w.system}: the change is there. Marked as saved.`, tone: 'ok' });
              }}
            >
              Check {w.system}
            </button>
            <button type="button" className="btn btn-small" disabled={!can.ok} title={can.reason} onClick={() => dispatch({ type: 'reconcile', id: w.id, how: 'retry' })}>
              Send again
            </button>
            <button
              type="button"
              className="btn btn-quiet btn-small"
              onClick={() => {
                dispatch({ type: 'discardWrite', id: w.id });
                dispatch({ type: 'toast', text: 'Discarded. If it did reach HomeBox, it will show up after the next sync.', tone: 'info' });
              }}
            >
              Discard
            </button>
          </div>
          <p className="fine">Check first. Only send again if you know it didn’t save, or it may be applied twice.</p>
        </>
      )}
      {w.status === 'queued' && (
        <div className="write-actions">
          <button type="button" className="btn btn-quiet btn-small" onClick={() => dispatch({ type: 'discardWrite', id: w.id })}>
            Cancel
          </button>
        </div>
      )}
    </li>
  );
}

export function ChangesView() {
  const { house, state } = useStore();
  const focus = state.changesFocus;
  const review = house.writes.filter((w) => w.status === 'conflict' || w.status === 'uncertain');
  const active = house.writes.filter((w) => w.status === 'queued' || w.status === 'running');
  const past = house.writes.filter((w) => w.status === 'completed' || w.status === 'discarded').sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  const activity = [...house.history].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 14);
  const list = (ws: WriteOp[]) => (
    <ul className="write-list">
      {ws.map((w) => (
        <WriteRow key={w.id} w={w} focused={focus === w.id} />
      ))}
    </ul>
  );
  return (
    <div className="view">
      <header className="view-head">
        <h1>Changes</h1>
        <p>Every edit goes through here: queued, sending, saved, unknown or in conflict. All of it is simulated in this browser.</p>
      </header>
      {state.settings.outage && <Note tone="warn">HomeBox is unreachable. New HomeBox edits are paused and nothing is queued offline. Atlas links still work.</Note>}
      <div className="changes-grid">
        <div>
          <section className="section">
            <header className="section-head">
              <h3>
                Needs review<span className="section-count">{review.length}</span>
              </h3>
            </header>
            {review.length ? list(review) : <Empty>Nothing to review.</Empty>}
          </section>
          <section className="section">
            <header className="section-head">
              <h3>
                In progress<span className="section-count">{active.length}</span>
              </h3>
            </header>
            {active.length ? list(active) : <Empty>Nothing being saved right now.</Empty>}
          </section>
          <section className="section">
            <header className="section-head">
              <h3>
                Finished<span className="section-count">{past.length}</span>
              </h3>
            </header>
            {past.length ? list(past) : <Empty>No finished changes yet.</Empty>}
          </section>
        </div>
        <div>
          <Sources house={house} outage={state.settings.outage} />
          <section className="section">
            <header className="section-head">
              <h3>Recent activity</h3>
            </header>
            <ol className="history">
              {activity.map((e) => (
                <li key={e.id}>
                  <span className="history-when">{fmtDateTime(e.at)}</span>
                  <span className="history-what">
                    {e.what} <EntityLink id={e.targetId} />
                  </span>
                  <span className="history-who">
                    {e.who}, in {e.system}
                  </span>
                </li>
              ))}
            </ol>
          </section>
        </div>
      </div>
    </div>
  );
}
