import { useState } from 'react';
import { roomContents, unplaced, dueState, CLAIM_LABEL } from '../data/query';
import { useSelect, useStore } from '../state/store';
import { ROOM_TINT, ROOM_KIND_LABEL } from '../atlas/palette';
import { EntityLink, Empty } from '../components/ui';

export function RoomsView() {
  return (
    <div className="view">
      <header className="view-head">
        <h1>Rooms</h1>
        <p>Every room, with or without a drawn shape, and everything that can’t be placed yet.</p>
      </header>
      <RoomIndex />
    </div>
  );
}

export function RoomIndex() {
  const { house, state } = useStore();
  const select = useSelect();
  const [floorFilter, setFloorFilter] = useState<string>('all');
  const floors = [...house.floors].sort((a, b) => b.order - a.order);
  const shown = floorFilter === 'all' ? floors : floors.filter((f) => f.id === floorFilter);
  const un = unplaced(house);
  const selectedId = state.selection?.id;

  return (
    <div className="room-index">
      <div className="filter-row" role="group" aria-label="Filter by floor">
        <button type="button" className="chip-btn" aria-pressed={floorFilter === 'all'} onClick={() => setFloorFilter('all')}>
          All floors
        </button>
        {floors.map((f) => (
          <button key={f.id} type="button" className="chip-btn" aria-pressed={floorFilter === f.id} onClick={() => setFloorFilter(f.id)}>
            {f.name}
          </button>
        ))}
      </div>

      {shown.map((f) => {
        const rooms = house.spaces.filter((s) => s.floorId === f.id && s.kind !== 'stair');
        return (
          <section key={f.id} className="ledger" aria-labelledby={`ledger-${f.id}`}>
            <div className="ledger-floor" aria-hidden="true">
              {f.short}
            </div>
            <div className="ledger-body">
              <h2 id={`ledger-${f.id}`} className="ledger-title">
                {f.name}
                {!f.hasPlan && <span className="mini-claim claim-unknown">No plan</span>}
              </h2>
              {!rooms.length && <Empty>No rooms recorded on this floor.</Empty>}
              <ul className="ledger-rows">
                {rooms.map((r) => {
                  const c = roomContents(house, r.id);
                  const due = c.tasks.filter((t) => dueState(t) === 'overdue' || dueState(t) === 'soon').length;
                  return (
                    <li key={r.id} className={`ledger-row${selectedId === r.id ? ' is-selected' : ''}`}>
                      <button type="button" className="ledger-main" onClick={() => select(r.id)}>
                        <span className="ledger-swatch" style={{ background: ROOM_TINT[r.kind] }} aria-hidden="true" />
                        <span className="ledger-name">{r.name}</span>
                        <span className="ledger-kind">{ROOM_KIND_LABEL[r.kind]}</span>
                        <span className="ledger-facts">
                          <span>{c.items.length} belongings</span>
                          <span>{c.docs.length} documents</span>
                          {c.outlets.length > 0 && <span>{c.outlets.length} outlets</span>}
                          {c.valves.length > 0 && <span>{c.valves.length} valves</span>}
                          {c.devices.length > 0 && <span>{c.devices.length} devices</span>}
                          {due > 0 && <span className="tone-alert">{due} upkeep due</span>}
                        </span>
                        <span className={`ledger-shape${r.geometry === 'reviewed' ? '' : ' is-none'}`}>{r.geometry === 'reviewed' ? 'Shape reviewed' : 'No shape'}</span>
                      </button>
                      {c.containers.length > 0 && (
                        <ul className="ledger-storage" aria-label={`Storage in ${r.name}`}>
                          {c.containers.map((ct) => (
                            <li key={ct.id}>
                              <EntityLink id={ct.id} sub={`${ct.kind}, ${house.items.filter((i) => i.containerId === ct.id).length} inside. Storage, not a room.`} />
                            </li>
                          ))}
                        </ul>
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>
          </section>
        );
      })}

      <section className="ledger ledger-unplaced" aria-labelledby="ledger-unplaced">
        <div className="ledger-floor" aria-hidden="true">
          ?
        </div>
        <div className="ledger-body">
          <h2 id="ledger-unplaced" className="ledger-title">
            Not placed
          </h2>
          <p className="body-text muted">Records stay visible even when nobody knows exactly where they are. Nothing is hidden or guessed.</p>
          <div className="unplaced-grid">
            <div>
              <h3>No known location</h3>
              {un.noRoomItems.length ? (
                <ul className="rows">
                  {un.noRoomItems.map((i) => (
                    <li key={i.id} className="link-row">
                      <EntityLink id={i.id} sub={i.locationNote ?? CLAIM_LABEL[i.locationClaim]} />
                    </li>
                  ))}
                </ul>
              ) : (
                <Empty>Everything has a room.</Empty>
              )}
            </div>
            <div>
              <h3>Known by room, spot not recorded</h3>
              {un.roomOnlyItems.length ? (
                <ul className="rows">
                  {un.roomOnlyItems.map((i) => (
                    <li key={i.id} className="link-row">
                      <EntityLink id={i.id} />
                    </li>
                  ))}
                </ul>
              ) : (
                <Empty>None.</Empty>
              )}
            </div>
            <div>
              <h3>Valves without a position</h3>
              {un.valves.length ? (
                <ul className="rows">
                  {un.valves.map((v) => (
                    <li key={v.id} className="link-row">
                      <EntityLink id={v.id} sub={v.note} />
                    </li>
                  ))}
                </ul>
              ) : (
                <Empty>All valves are placed.</Empty>
              )}
            </div>
            <div>
              <h3>Network devices without a location</h3>
              {un.devices.length ? (
                <ul className="rows">
                  {un.devices.map((d) => (
                    <li key={d.id} className="link-row">
                      <EntityLink id={d.id} sub={d.note} />
                    </li>
                  ))}
                </ul>
              ) : (
                <Empty>All devices have a location.</Empty>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
