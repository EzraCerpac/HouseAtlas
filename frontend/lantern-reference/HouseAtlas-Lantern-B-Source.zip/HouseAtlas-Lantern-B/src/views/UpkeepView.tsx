import type { Task } from '../data/types';
import { dueState } from '../data/query';
import { useStore } from '../state/store';
import { TaskRow } from '../components/rows';
import { Empty, Note } from '../components/ui';

const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function DateMark({ iso }: { iso?: string }) {
  if (!iso) return <span className="tl-date" aria-hidden="true" />;
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return (
    <time className="tl-date" dateTime={iso.slice(0, 10)}>
      <span className="tl-day">{d}</span>
      <span className="tl-mon">
        {MON[m - 1]} {y !== 2026 ? y : ''}
      </span>
    </time>
  );
}

function Group({ title, tasks, tone, dateOf }: { title: string; tasks: Task[]; tone: string; dateOf: (t: Task) => string | undefined }) {
  return (
    <section className={`tl-group tl-${tone}`} aria-labelledby={`tl-${tone}`}>
      <h2 id={`tl-${tone}`}>
        {title}
        <span className="section-count">{tasks.length}</span>
      </h2>
      {tasks.length ? (
        <ol className="timeline">
          {tasks.map((t) => (
            <li key={t.id} className="tl-row">
              <DateMark iso={dateOf(t)} />
              <ul className="rows">
                <TaskRow task={t} showTarget />
              </ul>
            </li>
          ))}
        </ol>
      ) : (
        <Empty>Nothing here.</Empty>
      )}
    </section>
  );
}

export function UpkeepView() {
  const { house, state } = useStore();
  const byDue = (a: Task, b: Task) => (a.due ?? '9999').localeCompare(b.due ?? '9999');
  const overdue = house.tasks.filter((t) => dueState(t) === 'overdue').sort(byDue);
  const soon = house.tasks.filter((t) => dueState(t) === 'soon').sort(byDue);
  const later = house.tasks.filter((t) => dueState(t) === 'later').sort(byDue);
  const done = house.tasks.filter((t) => t.status === 'done').sort((a, b) => (b.completedAt ?? '').localeCompare(a.completedAt ?? ''));
  return (
    <div className="view">
      <header className="view-head">
        <h1>Upkeep</h1>
        <p>Scheduled and completed maintenance for {house.name}. Upkeep is kept in HomeBox.</p>
      </header>
      {state.settings.outage && <Note tone="warn">HomeBox is unreachable, so tasks can’t be marked done right now. You are looking at the cached copy.</Note>}
      <Note>Repeats are added by hand. When you mark something done, you can choose a date for the next one.</Note>
      <div className="tl-columns">
        <div>
          <Group title="Overdue" tasks={overdue} tone="overdue" dateOf={(t) => t.due} />
          <Group title="Next two weeks" tasks={soon} tone="soon" dateOf={(t) => t.due} />
          <Group title="Later" tasks={later} tone="later" dateOf={(t) => t.due} />
        </div>
        <div>
          <Group title="Completed" tasks={done} tone="done" dateOf={(t) => t.completedAt} />
        </div>
      </div>
    </div>
  );
}
